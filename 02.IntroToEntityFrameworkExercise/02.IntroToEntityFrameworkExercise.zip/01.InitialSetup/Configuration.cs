﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _01.InitialSetup
{
    public class Configuration
    {
        public const string ConnectionString =
            @"Server=STANCHO-PC\SQLEXPRESS01;" +
            @"Database=MinionsDB;" +
            @"Integrated Security=true;";
    }
}
