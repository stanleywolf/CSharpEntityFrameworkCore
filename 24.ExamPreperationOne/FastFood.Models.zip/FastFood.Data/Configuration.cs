namespace FastFood.Data
{
	public static class Configuration
	{
		public static string ConnectionString = @"Server=STANCHO-PC\SQLEXPRESS01;Database=FastFood;Trusted_Connection=True";
	}
}