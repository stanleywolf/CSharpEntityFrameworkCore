﻿namespace PhotoShare.Models.Enums
{
    public enum Color
    {
        White,
        Green,
        Blue,
        Pink,
        Yellow,
        Black,
        Cyan,
        Magenta,
        Red,
        Purple,
        WhiteBlackGradient
    }
}
