﻿namespace PhotoShare.Client.Core.Commands
{
    public class PrintFriendsListCommand
    {
        
    }
}
