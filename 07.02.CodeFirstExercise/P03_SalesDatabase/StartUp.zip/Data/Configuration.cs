﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_SalesDatabase.Data
{
    public class Configuration
    {
        public const string ConnectionString =
            @"Server=STANCHO-PC\SQLEXPRESS01;Database=Sales;Integrated Security=True";
    }
}
