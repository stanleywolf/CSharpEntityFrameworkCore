﻿namespace SoftJail.Data
{
   public static class Configuration
    {
        public static string ConnectionString = @"Server=STANCHO-PC\SQLEXPRESS01;Database=SoftJail;Trusted_Connection=True";
    }
}
