﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01.ProductShop.Data
{
    public class Configuring
    {
        public const string ConnectionString = @"Server=STANCHO-PC\SQLEXPRESS01;Database=ProductShopDB;Integrated Security=True";
    }
}
